G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-09-30T22:45:07+02:00*
G04 #@! TF.ProjectId,Carte_NFC_KiCad,43617274-655f-44e4-9643-5f4b69436164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-09-30 22:45:07*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.000000*%
%ADD11RoundRect,0.225000X0.250000X-0.225000X0.250000X0.225000X-0.250000X0.225000X-0.250000X-0.225000X0*%
%ADD12R,0.250000X0.700000*%
%ADD13R,1.000000X0.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,AE1*
X110500000Y-123500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,C1*
X122500000Y-113375000D03*
X122500000Y-111825000D03*
G04 #@! TD*
G04 #@! TO.C,C2*
X125000000Y-113375000D03*
X125000000Y-111825000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,U1*
X128250000Y-111000000D03*
X127750000Y-111000000D03*
X127750000Y-113000000D03*
X128250000Y-113000000D03*
D13*
X128000000Y-112000000D03*
G04 #@! TD*
M02*
